package com.exercise.springproject.domain;

import org.springframework.boot.web.reactive.error.DefaultErrorAttributes;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.servlet.ModelAndView;
import javax.servlet.http.HttpServletResponse;
import java.util.Map;

public class Error extends DefaultErrorAttributes {
//    public ModelAndView resolveException(HttpServletRequest request, HttpServletResponse response, Object handler, Exception ex);
//    public Map<String, Object> getErrorAttributes(RequestAttributes requestAttributes, boolean includeStackTrace);
//    public Throwable getError(RequestAttributes requestAttributes);

}
